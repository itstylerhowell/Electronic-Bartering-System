#include <iostream>
#include <iomanip>
#include <sstream>
#include <ctime>
#include "Blockchain.h"

namespace {

void printHelp() {
    std::cout <<
        "\nCommands:\n"
        "  mint          Register a new item to an owner (must be mined before it can trade)\n"
        "  trade         Propose a barter trade of two already-minted items\n"
        "  mine          Mine all pending mints/trades into a new block\n"
        "  chain         Print the full blockchain\n"
        "  pending       Show transactions waiting to be mined\n"
        "  cancel        Drop all pending transactions and release their item locks\n"
        "  owners        Show current ownership of every known item\n"
        "  history <id>  Show all transactions involving a given party ID\n"
        "  validate      Check the chain's hash-links AND full ownership history\n"
        "  doublecommit  (demo) try to commit the same item to two trades at once\n"
        "  forge         (demo) sneak a forged double-spend directly into the chain\n"
        "  help          Show this menu\n"
        "  exit          Quit\n\n";
}

std::string prompt(const std::string& label) {
    std::cout << label;
    std::string line;
    std::getline(std::cin, line);
    return line;
}

std::string formatTime(time_t t) {
    char buf[32];
    std::strftime(buf, sizeof(buf), "%Y-%m-%d %H:%M:%S", std::localtime(&t));
    return std::string(buf);
}

void printTransaction(const BarterTransaction& tx) {
    std::cout << "    [" << formatTime(tx.timestamp) << "] ";
    if (tx.type == TxType::MINT) {
        std::cout << "MINT: \"" << tx.offeredByTo << "\" -> " << tx.toParty;
    } else {
        std::cout << "TRADE: " << tx.fromParty << " gives \"" << tx.offeredByFrom
                   << "\"  <->  " << tx.toParty << " gives \"" << tx.offeredByTo << "\"";
    }
    if (!tx.memo.empty()) std::cout << "  (" << tx.memo << ")";
    std::cout << "\n";
}

void printChain(const Blockchain& bc) {
    for (const auto& block : bc.getChain()) {
        std::cout << "Block #" << block.index << "\n"
                  << "  timestamp:     " << formatTime(block.timestamp) << "\n"
                  << "  previousHash:  " << block.previousHash << "\n"
                  << "  hash:          " << block.hash << "\n"
                  << "  nonce:         " << block.nonce << "\n"
                  << "  transactions:  " << block.transactions.size() << "\n";
        for (const auto& tx : block.transactions) printTransaction(tx);
        std::cout << "\n";
    }
}

} // namespace

int main() {
    Blockchain bc(4); // difficulty: 4 leading hex zeros ~ a second or two per block on a laptop

    std::cout << "=== BarterChain MVP ===\n"
              << "A proof-of-work blockchain for recording barter trades, with an\n"
              << "ownership ledger that locks items during pending trades to prevent\n"
              << "double-committing the same item to two deals at once.\n"
              << "Difficulty: " << bc.getDifficulty() << " leading hex zeros.\n";
    printHelp();

    std::string cmd;
    while (true) {
        std::cout << "> ";
        if (!std::getline(std::cin, cmd)) break;
        if (cmd.empty()) continue;

        std::istringstream iss(cmd);
        std::string action;
        iss >> action;

        if (action == "exit" || action == "quit") {
            break;
        } else if (action == "help") {
            printHelp();
        } else if (action == "mint") {
            std::string owner = prompt("  Owner party ID: ");
            std::string item = prompt("  Item ID/name (must be unique): ");
            std::string memo = prompt("  Memo (optional): ");
            TxResult r = bc.mintItem(owner, item, memo);
            if (r == TxResult::OK) {
                std::cout << "  Queued. Run 'mine' to confirm '" << item << "' belongs to " << owner << ".\n";
            } else {
                std::cout << "  Rejected: " << toString(r) << "\n";
            }
        } else if (action == "trade") {
            std::string from = prompt("  From party ID: ");
            std::string itemFrom = prompt("  Item '" + from + "' is giving up: ");
            std::string to = prompt("  To party ID: ");
            std::string itemTo = prompt("  Item '" + to + "' is giving up: ");
            std::string memo = prompt("  Memo (optional): ");
            TxResult r = bc.proposeTrade(from, to, itemFrom, itemTo, memo);
            if (r == TxResult::OK) {
                std::cout << "  Added to pending pool and locked. Run 'mine' to commit it.\n";
            } else {
                std::cout << "  Rejected: " << toString(r) << "\n";
            }
        } else if (action == "mine") {
            if (bc.getPending().empty()) {
                std::cout << "  Nothing pending to mine.\n";
                continue;
            }
            std::cout << "  Mining...\n";
            size_t n = bc.minePendingTransactions();
            std::cout << "  Mined block with " << n << " transaction(s). New hash: "
                      << bc.getChain().back().hash << "\n";
        } else if (action == "cancel") {
            bc.cancelPending();
            std::cout << "  Pending pool cleared, item locks released.\n";
        } else if (action == "chain") {
            printChain(bc);
        } else if (action == "pending") {
            const auto& p = bc.getPending();
            if (p.empty()) {
                std::cout << "  (none)\n";
            } else {
                for (const auto& tx : p) printTransaction(tx);
            }
        } else if (action == "owners") {
            const auto& own = bc.getOwnership();
            if (own.empty()) {
                std::cout << "  No items minted yet.\n";
            } else {
                const auto& reserved = bc.getReserved();
                for (const auto& [item, owner] : own) {
                    std::cout << "    " << item << "  ->  " << owner;
                    if (reserved.count(item)) std::cout << "   [LOCKED in pending trade]";
                    std::cout << "\n";
                }
            }
        } else if (action == "history") {
            std::string id;
            iss >> id;
            if (id.empty()) id = prompt("  Party ID: ");
            auto hist = bc.historyFor(id);
            if (hist.empty()) {
                std::cout << "  No recorded transactions for '" << id << "'.\n";
            } else {
                for (const auto& tx : hist) printTransaction(tx);
            }
        } else if (action == "validate") {
            std::cout << (bc.isChainValid()
                              ? "  Chain is valid: hash-linkage intact and no double-spends found.\n"
                              : "  Chain is INVALID — tampering or a double-spend was detected.\n");
        } else if (action == "doublecommit") {
            // Demonstrates that once an item is locked in a pending trade,
            // a second trade referencing that same item is rejected outright.
            std::cout << "  Minting 'Guitar' to Alice and 'Amp' to Bob, then mining...\n";
            bc.mintItem("Alice", "Guitar");
            bc.mintItem("Bob", "Amp");
            bc.minePendingTransactions();

            std::cout << "  Also minting 'Speaker' to Carol...\n";
            bc.mintItem("Carol", "Speaker");
            bc.minePendingTransactions();

            std::cout << "  Alice proposes: Guitar <-> Bob's Amp\n";
            TxResult r1 = bc.proposeTrade("Alice", "Bob", "Guitar", "Amp");
            std::cout << "    Result: " << toString(r1) << "\n";

            std::cout << "  Alice now ALSO tries to promise the same Guitar to Carol for the Speaker,\n"
                      << "  before the first trade is even mined:\n";
            TxResult r2 = bc.proposeTrade("Alice", "Carol", "Guitar", "Speaker");
            std::cout << "    Result: " << toString(r2) << "\n";
            if (r2 == TxResult::ITEM_RESERVED) {
                std::cout << "  -> Double-commit blocked: the Guitar was already locked in the first trade.\n";
            }
        } else if (action == "forge") {
            // Demonstrates that even bypassing proposeTrade() entirely and
            // hand-building a block with a valid proof-of-work hash, a
            // forged double-spend is still caught by full-chain replay.
            if (bc.getOwnership().empty()) {
                std::cout << "  Run 'doublecommit' first so there's an item ('Guitar') to forge with.\n";
                continue;
            }
            std::string owner = bc.ownerOf("Guitar");
            if (owner.empty()) {
                std::cout << "  No 'Guitar' item found — run 'doublecommit' first.\n";
                continue;
            }
            std::cout << "  Forging a block that re-sells '" << owner << "'s Guitar to 'Mallory',\n"
                      << "  even though it was already legitimately traded away...\n";
            std::vector<BarterTransaction> forged = {
                BarterTransaction::makeTrade(owner, "Mallory", "Guitar", "Speaker", "forged resale")
            };
            Block forgedBlock(static_cast<uint32_t>(bc.getChain().size()), forged, bc.getChain().back().hash);
            forgedBlock.mine(bc.getDifficulty()); // fully valid proof-of-work — hash-checking alone won't catch this
            bc.debugForceAppendBlock(forgedBlock);
            std::cout << "  Forged block appended with a legitimate hash. Try 'validate'.\n";
        } else {
            std::cout << "  Unknown command. Type 'help' for the list.\n";
        }
    }

    std::cout << "Goodbye.\n";
    return 0;
}
