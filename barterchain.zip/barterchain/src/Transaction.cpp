#include "Transaction.h"
#include <sstream>

std::string BarterTransaction::toString() const {
    std::ostringstream oss;
    oss << (type == TxType::MINT ? "MINT" : "TRADE") << "|"
        << fromParty << "|" << toParty << "|"
        << offeredByFrom << "|" << offeredByTo << "|"
        << memo << "|" << timestamp;
    return oss.str();
}
