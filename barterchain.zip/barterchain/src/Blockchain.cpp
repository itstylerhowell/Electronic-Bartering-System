#include "Blockchain.h"

const char* toString(TxResult result) {
    switch (result) {
        case TxResult::OK: return "OK";
        case TxResult::ITEM_NOT_FOUND: return "ITEM_NOT_FOUND: that item hasn't been minted yet";
        case TxResult::ITEM_ALREADY_EXISTS: return "ITEM_ALREADY_EXISTS: that item ID is already registered";
        case TxResult::NOT_OWNER: return "NOT_OWNER: that party doesn't currently own that item";
        case TxResult::ITEM_RESERVED: return "ITEM_RESERVED: that item is already locked in another pending trade (double-commit blocked)";
    }
    return "UNKNOWN";
}

Blockchain::Blockchain(uint32_t difficulty) : difficulty_(difficulty) {
    chain_.push_back(createGenesisBlock());
}

Block Blockchain::createGenesisBlock() const {
    return Block(0, {}, "0");
}

TxResult Blockchain::mintItem(const std::string& owner, const std::string& itemId,
                               const std::string& memo) {
    if (ownership_.count(itemId)) return TxResult::ITEM_ALREADY_EXISTS;
    if (reservedItems_.count(itemId)) return TxResult::ITEM_RESERVED; // already being minted this round

    pending_.push_back(BarterTransaction::makeMint(owner, itemId, memo));
    reservedItems_.insert(itemId);
    return TxResult::OK;
}

TxResult Blockchain::proposeTrade(const std::string& from, const std::string& to,
                                   const std::string& itemFrom, const std::string& itemTo,
                                   const std::string& memo) {
    auto ownerFromIt = ownership_.find(itemFrom);
    if (ownerFromIt == ownership_.end()) return TxResult::ITEM_NOT_FOUND;
    if (ownerFromIt->second != from) return TxResult::NOT_OWNER;

    auto ownerToIt = ownership_.find(itemTo);
    if (ownerToIt == ownership_.end()) return TxResult::ITEM_NOT_FOUND;
    if (ownerToIt->second != to) return TxResult::NOT_OWNER;

    if (reservedItems_.count(itemFrom)) return TxResult::ITEM_RESERVED;
    if (reservedItems_.count(itemTo)) return TxResult::ITEM_RESERVED;

    pending_.push_back(BarterTransaction::makeTrade(from, to, itemFrom, itemTo, memo));
    reservedItems_.insert(itemFrom);
    reservedItems_.insert(itemTo);
    return TxResult::OK;
}

void Blockchain::applyTransaction(const BarterTransaction& tx,
                                   std::unordered_map<std::string, std::string>& ownership) const {
    if (tx.type == TxType::MINT) {
        ownership[tx.offeredByTo] = tx.toParty;
    } else {
        // TRADE: ownership of the two items swaps between the parties.
        ownership[tx.offeredByFrom] = tx.toParty;
        ownership[tx.offeredByTo] = tx.fromParty;
    }
}

size_t Blockchain::minePendingTransactions() {
    if (pending_.empty()) return 0;

    Block newBlock(static_cast<uint32_t>(chain_.size()), pending_, chain_.back().hash);
    newBlock.mine(difficulty_);
    size_t count = pending_.size();

    for (const auto& tx : pending_) {
        applyTransaction(tx, ownership_);
    }

    chain_.push_back(newBlock);
    pending_.clear();
    reservedItems_.clear();
    return count;
}

void Blockchain::cancelPending() {
    pending_.clear();
    reservedItems_.clear();
}

bool Blockchain::isChainValid() const {
    // 1) Hash linkage check.
    for (size_t i = 1; i < chain_.size(); ++i) {
        const Block& current = chain_[i];
        const Block& previous = chain_[i - 1];
        if (current.hash != current.calculateHash()) return false; // tampered block contents
        if (current.previousHash != previous.hash) return false;   // broken link
    }

    // 2) Full ownership replay — catches a forged chain that's internally
    // hash-consistent but cheats on who actually owned what. This is what
    // makes double-spending an item detectable even if someone controls
    // the whole chain, not just the pending pool.
    std::unordered_map<std::string, std::string> replay;
    for (const auto& block : chain_) {
        for (const auto& tx : block.transactions) {
            if (tx.type == TxType::MINT) {
                if (replay.count(tx.offeredByTo)) return false; // item minted twice
            } else {
                auto fromIt = replay.find(tx.offeredByFrom);
                auto toIt = replay.find(tx.offeredByTo);
                if (fromIt == replay.end() || toIt == replay.end()) return false; // trading a nonexistent item
                if (fromIt->second != tx.fromParty) return false; // seller didn't own it — double-spend
                if (toIt->second != tx.toParty) return false;     // buyer didn't own their side
            }
            applyTransaction(tx, replay);
        }
    }

    return true;
}

std::vector<BarterTransaction> Blockchain::historyFor(const std::string& partyId) const {
    std::vector<BarterTransaction> result;
    for (const auto& block : chain_) {
        for (const auto& tx : block.transactions) {
            if (tx.fromParty == partyId || tx.toParty == partyId) {
                result.push_back(tx);
            }
        }
    }
    return result;
}

std::string Blockchain::ownerOf(const std::string& itemId) const {
    auto it = ownership_.find(itemId);
    return it == ownership_.end() ? std::string() : it->second;
}

void Blockchain::debugForceAppendBlock(const Block& block) {
    chain_.push_back(block);
}
