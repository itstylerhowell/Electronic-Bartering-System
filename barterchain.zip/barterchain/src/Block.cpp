#include "Block.h"
#include "sha256.h"
#include <sstream>

Block::Block(uint32_t idx, std::vector<BarterTransaction> txs, std::string prevHash)
    : index(idx), timestamp(std::time(nullptr)),
      transactions(std::move(txs)), previousHash(std::move(prevHash)),
      nonce(0) {
    hash = calculateHash();
}

std::string Block::calculateHash() const {
    std::ostringstream oss;
    oss << index << previousHash << timestamp << nonce;
    for (const auto& tx : transactions) {
        oss << tx.toString();
    }
    return SHA256::hash(oss.str());
}

void Block::mine(uint32_t difficulty) {
    std::string target(difficulty, '0');
    do {
        nonce++;
        hash = calculateHash();
    } while (hash.compare(0, difficulty, target) != 0);
}
