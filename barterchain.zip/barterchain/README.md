# BarterChain

A minimal proof-of-work blockchain, written in C++, for recording **barter trades**
instead of currency transactions — think Bitcoin's ledger mechanics, but each
"transaction" is "Party A gives up X, Party B gives up Y" rather than a
transfer of coins.

This is an MVP / learning-grade prototype: single-process, no networking yet,
no public/private key signing yet. It demonstrates the core mechanics that
matter — hashing, proof-of-work mining, chain linking, and tamper detection —
so those pieces can be extended toward a real distributed system.

## What's implemented

- **Self-contained SHA-256** (`src/sha256.cpp`) — no OpenSSL or other external
  crypto dependency, so it builds anywhere with a C++17 compiler. Verified
  against the standard NIST test vectors.
- **Block** (`src/Block.cpp`) — holds a batch of barter transactions, a
  timestamp, the previous block's hash, and a nonce found via proof-of-work.
- **Blockchain** (`src/Blockchain.cpp`) — maintains the chain, a pending
  transaction pool, mining, chain validation, and per-party trade history.
- **BarterTransaction** (`src/Transaction.cpp`) — two types: `MINT`
  (registers a new item to an owner) and `TRADE` (swaps two items between
  parties). Keeping both on-chain makes the entire ownership history
  auditable, not just assumed.
- **Ownership ledger and double-commit prevention** — ownership of every
  item is derived by replaying `MINT`/`TRADE` transactions from genesis
  (the same idea as Bitcoin's UTXO model, applied to unique items instead
  of coins). Proposing a trade checks that the proposer actually owns the
  item, and **locks** both items so neither can be committed to a second
  trade until the first one is mined or cancelled. `isChainValid()` also
  replays the full ownership history, so even a forged block with a
  perfectly valid proof-of-work hash gets caught if it tries to re-sell an
  item the "seller" didn't actually own at that point in history. The
  `doublecommit` and `forge` CLI commands demonstrate both cases live.
- **CLI** (`src/main.cpp`) — interactive shell to mint items, propose
  trades, mine blocks, inspect ownership, and validate integrity.

## What's *not* implemented yet (roadmap)

These are the natural next steps if you want to take this from prototype to
something real:

- **Peer-to-peer networking** — right now this is a single local chain.
  A real system needs nodes gossiping blocks/transactions and a consensus
  rule for resolving forks (e.g. longest valid chain).
- **Digital signatures** — transactions currently aren't cryptographically
  signed, so anyone could claim to be "Tyler" in a trade, or forge a MINT to
  themselves. You'd want each party to have a public/private keypair (e.g.
  ECDSA) and sign their side of a trade — this is what makes "trust without
  knowing the other person" hold up against an actively dishonest party,
  rather than just an honest-but-careless one.
- **Persistence** — the chain currently lives in memory and disappears on
  exit. Needs disk storage (even just JSON/append-only log to start).
- **Difficulty adjustment** — the mining difficulty is fixed; a real network
  adjusts it based on how fast blocks are being found.

## Build

Requires a C++17 compiler. No external dependencies.

```bash
g++ -std=c++17 -O2 -Wall -Iinclude src/*.cpp -o barterchain
./barterchain
```

A `CMakeLists.txt` is also included if you prefer CMake:

```bash
mkdir build && cd build
cmake ..
make
./barterchain
```

## Usage

```
=== BarterChain MVP ===
> mint
  Owner party ID: Tyler
  Item ID/name (must be unique): Old MacBook
  Memo (optional):
  Queued. Run 'mine' to confirm 'Old MacBook' belongs to Tyler.
> mint
  Owner party ID: Katherine
  Item ID/name (must be unique): Handmade Quilt
  Memo (optional):
  Queued. Run 'mine' to confirm 'Handmade Quilt' belongs to Katherine.
> mine
  Mined block with 2 transaction(s). New hash: 0000...
> trade
  From party ID: Tyler
  Item 'Tyler' is giving up: Old MacBook
  To party ID: Katherine
  Item 'Katherine' is giving up: Handmade Quilt
  Memo (optional): Craigslist deal
  Added to pending pool and locked. Run 'mine' to commit it.
> mine
  Mined block with 1 transaction(s). New hash: 0000...
> owners
    Handmade Quilt  ->  Tyler
    Old MacBook  ->  Katherine
> validate
  Chain is valid: hash-linkage intact and no double-spends found.
```

Commands: `mint`, `trade`, `mine`, `chain`, `pending`, `cancel`, `owners`,
`history <id>`, `validate`, `doublecommit` (demo: shows a second trade on a
locked item getting rejected), `forge` (demo: shows a forged double-spend
with a valid hash still getting caught by full-chain replay), `help`, `exit`.

## Project layout

```
barterchain/
├── CMakeLists.txt
├── README.md
├── include/
│   ├── Block.h
│   ├── Blockchain.h
│   ├── Transaction.h
│   └── sha256.h
└── src/
    ├── Block.cpp
    ├── Blockchain.cpp
    ├── Transaction.cpp
    ├── main.cpp
    └── sha256.cpp
```
