#ifndef BARTERCHAIN_TRANSACTION_H
#define BARTERCHAIN_TRANSACTION_H

#include <string>
#include <ctime>

// MINT registers a brand-new item to an owner (a one-time bootstrap event
// per item — like declaring "this guitar exists and belongs to Tyler").
// TRADE swaps ownership of two already-registered items between two parties.
// Keeping MINT on-chain (rather than as an in-memory assumption) means the
// entire ownership history — who has ever owned what — is auditable by
// replaying the chain from genesis.
enum class TxType { MINT, TRADE };

struct BarterTransaction {
    TxType type = TxType::TRADE;
    std::string fromParty;      // ID of party A (empty for MINT)
    std::string toParty;        // ID of party B, or the recipient for MINT
    std::string offeredByFrom;  // item ID fromParty is giving up (empty for MINT)
    std::string offeredByTo;    // item ID toParty is giving up; for MINT, the item being created
    std::string memo;           // optional notes on the deal
    time_t timestamp;

    BarterTransaction() = default;

    static BarterTransaction makeMint(std::string owner, std::string itemId,
                                       std::string note = "") {
        BarterTransaction tx;
        tx.type = TxType::MINT;
        tx.toParty = std::move(owner);
        tx.offeredByTo = std::move(itemId);
        tx.memo = std::move(note);
        tx.timestamp = std::time(nullptr);
        return tx;
    }

    static BarterTransaction makeTrade(std::string from, std::string to,
                                        std::string itemFrom, std::string itemTo,
                                        std::string note = "") {
        BarterTransaction tx;
        tx.type = TxType::TRADE;
        tx.fromParty = std::move(from);
        tx.toParty = std::move(to);
        tx.offeredByFrom = std::move(itemFrom);
        tx.offeredByTo = std::move(itemTo);
        tx.memo = std::move(note);
        tx.timestamp = std::time(nullptr);
        return tx;
    }

    // Serialized form used for hashing and display.
    std::string toString() const;
};

#endif
