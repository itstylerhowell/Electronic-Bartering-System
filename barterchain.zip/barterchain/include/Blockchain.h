#ifndef BARTERCHAIN_BLOCKCHAIN_H
#define BARTERCHAIN_BLOCKCHAIN_H

#include <vector>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include "Block.h"

// Why one item can't be committed to two trades at once:
//
// Ownership of every item is derived by replaying MINT/TRADE transactions
// from genesis (like Bitcoin's UTXO model, but for unique items instead of
// coins). A trade can only be proposed if the chain currently shows the
// proposer owns the item. The moment a trade is proposed, both items in it
// are "reserved" — locked out of any other pending trade — until that trade
// either gets mined (ownership updates on-chain) or is cancelled (the lock
// releases). That reservation is what makes double-commit impossible at
// submission time.
//
// isChainValid() goes further: it replays the *entire* history and confirms
// every trade was made by the item's actual owner at that point in time.
// That catches a forged/rewritten chain that tries to sneak in a double
// transfer of the same item, not just a corrupted hash.
enum class TxResult {
    OK,
    ITEM_NOT_FOUND,     // item was never minted / doesn't exist yet
    ITEM_ALREADY_EXISTS,// tried to mint an item ID that's already registered
    NOT_OWNER,          // party doesn't currently own the item they're offering
    ITEM_RESERVED       // item is already locked in another pending transaction (double-commit attempt)
};

const char* toString(TxResult result);

class Blockchain {
public:
    explicit Blockchain(uint32_t difficulty = 4);

    // Register a brand-new item to an owner. Must be mined before it can be traded.
    TxResult mintItem(const std::string& owner, const std::string& itemId,
                       const std::string& memo = "");

    // Propose a trade. Validates ownership and locks both items against
    // being committed to any other pending trade. Returns the specific
    // failure reason if it can't be proposed.
    TxResult proposeTrade(const std::string& from, const std::string& to,
                           const std::string& itemFrom, const std::string& itemTo,
                           const std::string& memo = "");

    // Mine all pending transactions into a new block, updating ownership
    // for every trade and releasing all reservations. Returns count mined.
    size_t minePendingTransactions();

    // Drop all pending transactions and release their item reservations
    // without mining them.
    void cancelPending();

    // Validates hash-linkage AND replays full ownership history to catch
    // any forged double-spend, not just a corrupted hash.
    bool isChainValid() const;

    std::vector<BarterTransaction> historyFor(const std::string& partyId) const;

    // Current confirmed owner of an item, or empty string if unknown/unminted.
    std::string ownerOf(const std::string& itemId) const;

    const std::unordered_map<std::string, std::string>& getOwnership() const { return ownership_; }
    const std::unordered_set<std::string>& getReserved() const { return reservedItems_; }
    const std::vector<Block>& getChain() const { return chain_; }
    const std::vector<BarterTransaction>& getPending() const { return pending_; }
    uint32_t getDifficulty() const { return difficulty_; }

    // Directly appends a pre-built block, bypassing all validation. Exists
    // only to demonstrate that isChainValid() catches a forged double-spend
    // even when the hash chain itself is internally consistent.
    void debugForceAppendBlock(const Block& block);

private:
    Block createGenesisBlock() const;
    void applyTransaction(const BarterTransaction& tx, std::unordered_map<std::string, std::string>& ownership) const;

    std::vector<Block> chain_;
    std::vector<BarterTransaction> pending_;
    std::unordered_map<std::string, std::string> ownership_; // itemId -> ownerPartyId
    std::unordered_set<std::string> reservedItems_;          // items locked by pending trades
    uint32_t difficulty_;
};

#endif
