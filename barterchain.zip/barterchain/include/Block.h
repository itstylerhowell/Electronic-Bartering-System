#ifndef BARTERCHAIN_BLOCK_H
#define BARTERCHAIN_BLOCK_H

#include <string>
#include <vector>
#include <cstdint>
#include "Transaction.h"

class Block {
public:
    Block(uint32_t index, std::vector<BarterTransaction> transactions,
          std::string previousHash);

    // Proof-of-work: find a nonce such that the block hash has `difficulty`
    // leading zero hex digits.
    void mine(uint32_t difficulty);

    std::string calculateHash() const;

    uint32_t index;
    time_t timestamp;
    std::vector<BarterTransaction> transactions;
    std::string previousHash;
    std::string hash;
    uint64_t nonce;
};

#endif
