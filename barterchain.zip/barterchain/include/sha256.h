#ifndef BARTERCHAIN_SHA256_H
#define BARTERCHAIN_SHA256_H

#include <string>
#include <cstdint>
#include <vector>

// Minimal, self-contained SHA-256 implementation (no external dependencies).
// Implements the algorithm as specified in FIPS 180-4.
class SHA256 {
public:
    SHA256();
    void update(const uint8_t* data, size_t len);
    void update(const std::string& data);
    std::string finalHex();

    static std::string hash(const std::string& input);

private:
    void transform(const uint8_t* chunk);

    uint32_t state_[8];
    uint64_t bitlen_;
    uint8_t buffer_[64];
    size_t bufferLen_;
};

#endif
